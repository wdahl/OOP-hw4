package albany.edu.hw4;

public interface Complementable<T> {
	T complement();
}
